
import React, { useState, useEffect, useCallback, useRef, StrictMode } from 'react';
import ReactDOM from 'react-dom/client';
import { GoogleGenAI } from "@google/genai"; // This import will be resolved by the importmap

// --- START OF TYPES ---
interface PricingItem {
  item: string;
  description: string;
  value: string;
  offered: string;
  icon?: React.ReactNode;
}

interface FormData {
  firstName: string;
  lastName: string;
  phone: string;
  email: string;
  pincode: string;
  businessCategory: string;
}

interface SocialLink {
  name: string;
  url: string;
  iconUrl: string;
}

interface IconProps {
  iconUrl: string;
  altText: string;
  className?: string;
  size?: number;
  wrapperClassName?: string;
}

interface HeroBannerProps {
  images: string[];
  slideDirection: 'left' | 'right';
}

interface CountdownTimerProps {
  targetDate: Date;
  segmentClassName?: string;
  numberClassName?: string;
  labelClassName?: string;
}

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

interface HeaderProps {
  logoUrl: string;
  title: string;
  tagline: string;
}

interface PricingTableProps {
  isVisible: boolean;
  onRevealPricesClick: () => void;
}

interface BookingFormModalProps {
  onSubmitSuccess: (formData: FormData) => void;
  onClose: () => void;
}

interface IconPanelItem {
  name: string;
  iconUrl: string;
}

interface WhyThisMattersItem {
  title: string;
  description: string;
  iconUrl: string;
}

interface AboutUsProps {
  logoUrl: string;
}

interface GeminiInsightsState {
  insights: string[];
  isLoading: boolean;
  error: string | null;
}

interface GeminiServiceResponse {
  data?: string[];
  error?: string;
}
// --- END OF TYPES ---

// --- START OF CONSTANTS ---
const BRAND_LOGO_URL = "https://res.cloudinary.com/dhyffe9mm/image/upload/v1749337493/ChatGPT_Image_Jun_8_2025_04_29_23_AM_gyozpg.png";
const SPINNER_LOGO_URL = "https://res.cloudinary.com/dhyffe9mm/image/upload/v1749768830/KRISHNA_GARDEN_VIRAr__1_-removebg-preview_1_awbusz.png";

const HERO_IMAGES_TOP: string[] = [
  "https://res.cloudinary.com/dhyffe9mm/image/upload/v1749663756/ChatGPT_Image_Jun_11_2025_08_27_25_PM_zw28ng.png",
  "https://res.cloudinary.com/dhyffe9mm/image/upload/v1749663756/ChatGPT_Image_Jun_11_2025_09_03_43_PM_tf57eo.png",
  "https://res.cloudinary.com/dhyffe9mm/image/upload/v1749663756/ChatGPT_Image_Jun_11_2025_08_54_42_PM_u9gqoy.png",
  "https://res.cloudinary.com/dhyffe9mm/image/upload/v1749663756/ChatGPT_Image_Jun_11_2025_08_29_21_PM_gesdg9.png",
  "https://res.cloudinary.com/dhyffe9mm/image/upload/v1749663756/ChatGPT_Image_Jun_11_2025_08_32_20_PM_jhctrf.png"
];

const HERO_IMAGES_MID: string[] = [
  "https://res.cloudinary.com/dhyffe9mm/image/upload/v1749663754/ChatGPT_Image_Jun_11_2025_08_35_28_PM_cpubtg.png",
  "https://res.cloudinary.com/dhyffe9mm/image/upload/v1749663755/ChatGPT_Image_Jun_11_2025_08_57_12_PM_cca5oj.png",
  "https://res.cloudinary.com/dhyffe9mm/image/upload/v1749663754/ChatGPT_Image_Jun_11_2025_09_09_00_PM_sj6exw.png",
  "https://res.cloudinary.com/dhyffe9mm/image/upload/v1749663754/ChatGPT_Image_Jun_11_2025_09_20_07_PM_wfrc79.png",
  "https://res.cloudinary.com/dhyffe9mm/image/upload/v1749663752/ChatGPT_Image_Jun_11_2025_09_24_22_PM_fkkvai.png"
];

const PRICING_DATA: PricingItem[] = [
  { item: "Full Website", description: "Homepage with trust design", value: "₹2999", offered: "₹1499" },
  { item: "Campaign Page", description: "For launches/offers", value: "₹2499", offered: "₹1249" },
  { item: "Booking Form", description: "Lead form + GSheet link", value: "₹1999", offered: "₹999" },
  { item: "QR Code", description: "For print & digital", value: "₹499", offered: "₹249" },
  { item: "Hosting", description: "Fast, secure, forever", value: "₹499", offered: "₹249" },
  { item: "Creative Flow", description: "Smart layout planning", value: "₹2499", offered: "₹1249" },
  { item: "Mobile Friendly", description: "Fully responsive site", value: "₹999", offered: "₹499" },
  { item: "WhatsApp Logic", description: "Direct chat integration", value: "₹499", offered: "₹249" },
];

const GOOGLE_SHEET_URL = "https://script.google.com/macros/s/AKfycbwO4T4NVbrbzTGgb4F4gRJxJyNug5BB3YZgjsYndKIOgIQ4OkpL6V2dQPkTQako86s0/exec";

const ICON_URLS = {
  check: "https://api.iconify.design/mdi:check-circle.svg?color=%23f1c40f",
  whatsapp: "https://api.iconify.design/ri:whatsapp-fill.svg?color=%23f1c40f",
  form: "https://api.iconify.design/fluent:form-new-20-filled.svg?color=%23f1c40f",
  googleSheets: "https://res.cloudinary.com/dyhsnmziv/image/upload/v1749700528/ChatGPT_Image_Jun_12_2025_09_25_05_AM_adhyq5.png",
  qrCode: "https://api.iconify.design/mdi:qrcode.svg?color=%23f1c40f",
  mobileOptimized: "https://api.iconify.design/mdi:cellphone-link.svg?color=%23f1c40f",
  hosting: "https://api.iconify.design/mdi:cloud-upload.svg?color=%23f1c40f",
  campaignLogic: "https://api.iconify.design/mdi:bullhorn-variant.svg?color=%23f1c40f",
  trustShield: "https://api.iconify.design/mdi:shield-check.svg?color=%23f1c40f",
  share: "https://api.iconify.design/mdi:share-circle.svg?color=%23f1c40f",
  simpleShare: "https://api.iconify.design/mdi:share-variant-outline.svg?color=%23f1c40f",
  uploadCue: "https://api.iconify.design/mdi:arrow-up-thin-circle-outline.svg?color=%23f1c40f",
  gift: "https://api.iconify.design/mdi:gift.svg?color=%23f1c40f",
  timer: "https://api.iconify.design/mdi:timer-sand.svg?color=%23f1c40f",
  tools: "https://api.iconify.design/mdi:tools.svg?color=%23f1c40f",
  arrowRight: "https://api.iconify.design/mdi:arrow-right-circle.svg?color=%23f1c40f",
  chevronDown: "https://api.iconify.design/mdi:chevron-down.svg?color=%23f1c40f",
  linkVariant: "https://api.iconify.design/mdi:link-variant.svg?color=%23f1c40f",
  facebook: "https://api.iconify.design/mdi:facebook.svg?color=%23f1c40f",
  twitter: "https://api.iconify.design/mdi:twitter.svg?color=%23f1c40f",
  star: "https://api.iconify.design/mdi:star-circle.svg?color=%23f1c40f",
  web: "https://api.iconify.design/mdi:web.svg?color=%23f1c40f",
  partyPopper: "https://api.iconify.design/mdi:party-popper.svg?color=%23f1c40f",
  rocketLaunch: "https://api.iconify.design/mdi:rocket-launch-outline.svg?color=%23f1c40f",
  lock: "https://api.iconify.design/mdi:lock-outline.svg?color=%23f1c40f",
};

const SOCIAL_LINKS: SocialLink[] = [
  { name: "Instagram", url: "https://www.instagram.com/uday_kumar1430?igsh=OWhxcTI4YnB4ZHZz", iconUrl: "https://api.iconify.design/mdi:instagram.svg?color=%23f1c40f" },
  { name: "YouTube", url: "https://youtube.com/@ukcreationentertainments6696?si=rV5Ay25D6C9JXbUa", iconUrl: "https://api.iconify.design/mdi:youtube.svg?color=%23f1c40f" },
  { name: "Facebook", url: "https://www.facebook.com/share/189c2NvUec/?mibextid=wwXIfr", iconUrl: ICON_URLS.facebook },
  { name: "Email", url: "mailto:udaykumar.uk1@gmail.com", iconUrl: "https://api.iconify.design/mdi:email.svg?color=%23f1c40f" },
  { name: "WhatsApp", url: "https://wa.me/+919867677928", iconUrl: ICON_URLS.whatsapp }
];

const ICON_PANEL_ITEMS: IconPanelItem[] = [
  { name: "WhatsApp", iconUrl: ICON_URLS.whatsapp },
  { name: "Hosting", iconUrl: ICON_URLS.hosting },
  { name: "QR Code", iconUrl: ICON_URLS.qrCode },
  { name: "Google Sheet", iconUrl: ICON_URLS.googleSheets },
  { name: "Mobile Friendly", iconUrl: ICON_URLS.mobileOptimized },
  { name: "Share", iconUrl: ICON_URLS.share },
  { name: "Campaign", iconUrl: ICON_URLS.campaignLogic },
  { name: "Trust Shield", iconUrl: ICON_URLS.trustShield },
  { name: "Form Submit", iconUrl: ICON_URLS.form }
];

const WHO_NEEDS_THIS_POINTS: string[] = [
  "Small Businesses",
  "Local Shops",
  "Service Providers",
  "Clinics & Gyms",
  "Salons & Spas",
  "Personal Brands",
  "Resellers",
  "New Entrepreneurs",
  "Home Food Creators (Cakes, Cookies, Snacks)"
];

const WHY_THIS_MATTERS_DATA: WhyThisMattersItem[] = [
  { title: "TRUST BUILDING", description: "People buy from people they trust. A clean webpage creates that trust in seconds.", iconUrl: ICON_URLS.trustShield },
  { title: "24/7 VISIBILITY", description: "Your business gets seen even when you sleep – by anyone, anytime.", iconUrl: ICON_URLS.trustShield },
  { title: "INSTANT WHATSAPP LEADS", description: "No tech skills needed. Customers click and contact you directly.", iconUrl: ICON_URLS.trustShield },
  { title: "PORTFOLIO POWER", description: "Every booking & client builds your brand library.", iconUrl: ICON_URLS.trustShield },
  { title: "FUTURE READY", description: "This setup is not a design; it's your personal shop-window for today and tomorrow.", iconUrl: ICON_URLS.trustShield }
];

const GOOGLE_PAY_QR_CODE_URL = "https://res.cloudinary.com/dhyffe9mm/image/upload/v1749771339/UK_CREATION_y9bsxt.png";

const PREPAID_OFFER_FREEBIES_ITEMS = [
    { name: "Campaign Page", iconUrl: ICON_URLS.campaignLogic, value: "₹1249" },
    { name: "WhatsApp Direct Chat", iconUrl: ICON_URLS.whatsapp, value: "₹249" },
    { name: "QR Code for Print/Digital", iconUrl: ICON_URLS.qrCode, value: "₹249" },
];
const PREPAID_OFFER_FREEBIES_TOTAL_VALUE = "₹1747";
// --- END OF CONSTANTS ---

// --- START OF SERVICES ---
const fetchGeminiInsights = async (
  promptText: string,
  expectedPoints: number = 5
): Promise<GeminiServiceResponse> => {
  
  if (typeof GoogleGenAI !== 'function') {
    console.error("GoogleGenAI class is not available or not a function. Check import from @google/genai and ensure the library loaded correctly. Module:", GoogleGenAI);
    return { error: "Gemini API client (GoogleGenAI class) is not available or not correctly loaded. Please contact support." };
  }

  try {
    const apiKey = process.env.API_KEY;

    if (typeof apiKey !== 'string' || apiKey.trim() === '') {
        let problemDetail = "is not a string or is empty";
        if (typeof process === 'undefined') {
            problemDetail = "'process' object is undefined in this environment";
        } else if (!process.env) {
            problemDetail = "'process.env' object is undefined";
        } else if (typeof process.env.API_KEY === 'undefined') {
            problemDetail = "'process.env.API_KEY' is undefined";
        }
        console.error(`Gemini API Key issue: API_KEY from process.env ${problemDetail}. It must be a non-empty string as per SDK requirements.`);
        return { error: `Gemini client initialization failed: API key from environment ${problemDetail}. Please ensure it's correctly configured.` };
    }
    
    const ai = new GoogleGenAI({ apiKey: apiKey });

    const result = await ai.models.generateContent({
      model: 'gemini-2.5-flash-preview-04-17',
      contents: promptText,
    });

    const textResponse = result.text;

    if (typeof textResponse !== 'string') {
      console.error("Unexpected response format from Gemini API:", result);
      return { error: "Received an unexpected response format from the AI. Please try again." };
    }

    const bulletPoints = textResponse.split(/\r?\n/).map(bp => bp.trim()).filter(bp => bp.length > 0);

    if (bulletPoints.length > 0) {
      return { data: bulletPoints.slice(0, expectedPoints) };
    } else {
      console.warn("Gemini API returned an empty or non-bulleted response for insights. Prompt:", promptText);
      return { data: [] };
    }
  } catch (err: any) {
    console.error("Error during Gemini operation (fetching insights or SDK initialization):", err);
    let errorMessage = "Failed to generate insights. Please try again or contact support if the issue persists.";
    
    if (err instanceof Error) {
      if (err.name === 'ReferenceError' && err.message.toLowerCase().includes("process is not defined")) {
        errorMessage = "Failed to generate insights: The 'process' object, required for API key access, is not defined in this environment. This is a critical setup issue for using the Gemini API as configured.";
      } else {
        errorMessage = `Failed to generate insights: ${err.message}. Please try again or contact support.`;
      }
    } else if (typeof err === 'string') {
      errorMessage = `Failed to generate insights: ${err}. Please try again or contact support.`;
    }
    
    const errString = (err && err.message ? err.message : String(err)).toLowerCase();
    if (errString.includes("api key") || errString.includes("api_key") || errString.includes("credential") || errString.includes("permission denied") || errString.includes("authentication")) {
         errorMessage = "Failed to generate insights due to an API key or authentication issue. Please ensure the API key (from process.env.API_KEY) is correctly configured, valid, and has the necessary permissions.";
    }
    
    return { error: errorMessage };
  }
};
// --- END OF SERVICES ---

// --- START OF COMPONENTS ---

const Icon: React.FC<IconProps> = ({ iconUrl, altText, className = "", size = 24, wrapperClassName = 'bg-black' }) => {
  return (
    <span
      className={`inline-flex items-center justify-center p-1 rounded-full ${wrapperClassName} ring-1 ring-gray-400/70 ${className}`}
      style={{ width: size + 8, height: size + 8 }}
      aria-hidden="true"
    >
      <img
        src={iconUrl}
        alt={altText}
        width={size}
        height={size}
        className="object-contain"
      />
    </span>
  );
};

const Header: React.FC<HeaderProps> = ({ logoUrl, title, tagline }) => {
  return (
    <header className="bg-black py-4 shadow-xl sticky top-0 z-50">
      <div className="container mx-auto px-4 flex flex-col md:flex-row items-center justify-start">
        <div className="flex items-center mb-4 md:mb-0">
          <img src={logoUrl} alt="UK Creation Logo" className="h-16 w-16 md:h-20 md:w-20 mr-4 rounded-full border-2 border-yellow-400 shadow-md ring-1 ring-gray-400/50 ring-offset-2 ring-offset-black" />
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-yellow-400 leading-tight">{title}</h1>
            <p className="text-sm md:text-md text-gray-300 mt-1">{tagline}</p>
          </div>
        </div>
      </div>
    </header>
  );
};

const HeroBanner: React.FC<HeroBannerProps> = ({ images, slideDirection }) => {
  const sectionRef = useRef<HTMLElement>(null);
  const [imageWidth, setImageWidth] = useState(0);

  useEffect(() => {
    const updateWidth = () => {
      if (sectionRef.current) {
        setImageWidth(sectionRef.current.offsetWidth);
      }
    };

    updateWidth();
    window.addEventListener('resize', updateWidth);
    return () => window.removeEventListener('resize', updateWidth);
  }, []);

  if (!images || images.length === 0) return null;

  const animationName = slideDirection === 'right' ? 'scroll-continuous-right' : 'scroll-continuous-left';
  const animationDuration = `${images.length * 5}s`;

  return (
    <section ref={sectionRef} className="relative w-full h-80 md:h-[500px] overflow-hidden rounded-lg shadow-2xl">
      {imageWidth > 0 && (
        <div
          className={`flex h-full [animation-timing-function:linear] [animation-iteration-count:infinite]`}
          style={{
            width: `${images.length * 2 * imageWidth}px`,
            animationName: animationName,
            animationDuration: animationDuration,
          } as React.CSSProperties}
        >
          {[...images, ...images].map((src, index) => (
            <div
              key={`${slideDirection}-image-${index}`}
              className="flex-shrink-0 h-full"
              style={{ width: `${imageWidth}px` }}
            >
              <img
                src={src}
                alt={`Showcase ${slideDirection} image ${index % images.length + 1}`}
                className="w-full h-full object-cover"
              />
            </div>
          ))}
        </div>
      )}
    </section>
  );
};

const ValuePromiseBar: React.FC = () => {
  return (
    <section className="py-6 bg-yellow-400 text-gray-900 rounded-lg shadow-lg border border-gray-300/70">
      <div className="container mx-auto px-4 text-center">
        <p className="text-md sm:text-lg md:text-xl font-bold">
          Trusted Look • Mobile-Optimized • WhatsApp-Connected • Fast Booking • Zero Tech Confusion
        </p>
      </div>
    </section>
  );
};

const CountdownTimer: React.FC<CountdownTimerProps> = ({
  targetDate,
  segmentClassName,
  numberClassName,
  labelClassName
}) => {
  const calculateTimeLeft = useCallback((): TimeLeft | null => {
    if (!targetDate) return null;
    const difference = +targetDate - +new Date();
    if (difference <= 0) {
      return null;
    }
    return {
      days: Math.floor(difference / (1000 * 60 * 60 * 24)),
      hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
      minutes: Math.floor((difference / 1000 / 60) % 60),
      seconds: Math.floor((difference / 1000) % 60),
    };
  }, [targetDate]);

  const [timeLeft, setTimeLeft] = useState<TimeLeft | null>(calculateTimeLeft());

  useEffect(() => {
    if (!targetDate) {
      setTimeLeft(null);
      return;
    }
    setTimeLeft(calculateTimeLeft());
    const timerId = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);
    return () => clearInterval(timerId);
  }, [calculateTimeLeft, targetDate]);

  if (!timeLeft) {
    return <span className="text-red-700 font-semibold text-xl">Offer Expired!</span>;
  }

  const defaultSegmentClass = "flex flex-col items-center p-2 bg-gray-800/20 rounded-md shadow-md";
  const defaultNumberClass = "text-2xl md:text-4xl font-bold";
  const defaultLabelClass = "text-xs uppercase text-gray-800";

  return (
    <div className={`flex space-x-2 md:space-x-4 items-center justify-center ${!segmentClassName ? 'text-gray-100' : ''}`}>
      {(Object.keys(timeLeft) as Array<keyof TimeLeft>).map((interval) => (
        <div key={interval} className={segmentClassName || defaultSegmentClass}>
          <span className={numberClassName || defaultNumberClass}>{String(timeLeft[interval]).padStart(2, '0')}</span>
          <span className={labelClassName || defaultLabelClass}>{interval}</span>
        </div>
      ))}
    </div>
  );
};

const LIMITED_TIME_DEAL_EXPIRY_KEY = 'ukCreationLimitedTimeDealExpiry_v1';
interface LimitedTimeDealProps {
  isPricingVisible: boolean;
}

const LimitedTimeDeal: React.FC<LimitedTimeDealProps> = ({ isPricingVisible }) => {
  const [offerEndDate, setOfferEndDate] = useState<Date | null>(null);

  useEffect(() => {
    try {
      let expiryDateToSet: Date | null = null;
      const storedExpiry = localStorage.getItem(LIMITED_TIME_DEAL_EXPIRY_KEY);

      if (storedExpiry) {
        const expiryTimestamp = parseInt(storedExpiry, 10);
        if (!isNaN(expiryTimestamp) && expiryTimestamp > Date.now()) {
          expiryDateToSet = new Date(expiryTimestamp);
        } else {
          localStorage.removeItem(LIMITED_TIME_DEAL_EXPIRY_KEY);
        }
      }

      if (!expiryDateToSet) {
        const newExpiry = new Date();
        newExpiry.setDate(newExpiry.getDate() + 7);
        localStorage.setItem(LIMITED_TIME_DEAL_EXPIRY_KEY, newExpiry.getTime().toString());
        expiryDateToSet = newExpiry;
      }
      setOfferEndDate(expiryDateToSet);
    } catch (e) {
        console.warn("localStorage access failed in LimitedTimeDeal. Offer persistence may not work.", e);
        const tempExpiry = new Date();
        tempExpiry.setDate(tempExpiry.getDate() + 7);
        setOfferEndDate(tempExpiry);
    }
  }, []);

  const handleDealClick = () => {
    if (!isPricingVisible) {
      const pricingSection = document.getElementById('pricing');
      if (pricingSection) {
        pricingSection.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <section className="py-12 bg-gray-800 text-yellow-400 rounded-lg shadow-xl border border-gray-400/60">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-4 flex items-center justify-center">
          <Icon iconUrl={ICON_URLS.partyPopper} altText="" size={36} wrapperClassName="bg-transparent ring-0 !p-0" className="mr-2 text-yellow-400"/>
            LIMITED TIME OFFER
          <Icon iconUrl={ICON_URLS.partyPopper} altText="" size={36} wrapperClassName="bg-transparent ring-0 !p-0" className="ml-2 text-yellow-400"/>
        </h2>
        <div className="mb-8">
          {offerEndDate ? (
            <CountdownTimer
              targetDate={offerEndDate}
              segmentClassName="flex flex-col items-center p-2 bg-yellow-500/20 rounded-md shadow-md text-yellow-400 border border-gray-300/70"
              numberClassName="text-2xl md:text-4xl font-bold"
              labelClassName="text-xs uppercase text-yellow-300/80"
            />
          ) : (
            <div className="text-xl text-gray-400">Loading offer details...</div>
          )}
        </div>
        <div
          className={`bg-yellow-400 text-gray-900 p-6 rounded-lg shadow-inner max-w-2xl mx-auto border border-gray-700/50 
            ${!isPricingVisible ? 'cursor-pointer hover:bg-yellow-500 transition-colors duration-200 ease-in-out transform hover:scale-105' : 'opacity-90'}`}
          onClick={handleDealClick}
          onKeyPress={!isPricingVisible ? (e) => e.key === 'Enter' && handleDealClick() : undefined}
          tabIndex={!isPricingVisible ? 0 : -1}
          role={!isPricingVisible ? "button" : undefined}
          aria-label={!isPricingVisible ? "Scroll to pricing section to unlock this bonus and reveal prices" : "Bonus offer details"}
        >
          <div className="flex flex-col sm:flex-row items-center justify-center text-center sm:text-left">
            <Icon
              iconUrl={ICON_URLS.gift}
              altText="Gift Icon"
              size={36}
              wrapperClassName="bg-gray-800"
              className="mr-0 sm:mr-4 mb-3 sm:mb-0 flex-shrink-0"
            />
            <div>
              <p className="text-xl md:text-2xl font-semibold leading-tight">
                Bonus Page + QR Code + Responsive Layout Included
              </p>
              <p className="text-md md:text-lg text-gray-700/80 mt-1">
                {!isPricingVisible ? "Click to explore pricing & unlock this bonus!" : "This bonus was part of your unlocked package!"}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const AboutUs: React.FC<AboutUsProps> = ({ logoUrl }) => {
  const experiencePoints = [
    "Photography, Video Shooting",
    "Editing, Reels Creation",
    "Social Media Marketing",
    "Ex-Team Leadership in Marketing"
  ];

  return (
    <section className="py-12 bg-gray-800 rounded-lg shadow-xl border border-gray-400/60">
      <div className="container mx-auto px-6 text-center">
        <img
          src={logoUrl}
          alt="UK Creation Brand Logo"
          className="h-24 w-24 md:h-32 md:w-32 rounded-full border-4 border-yellow-400 shadow-lg mx-auto mb-8 ring-1 ring-gray-400/50 ring-offset-2 ring-offset-black"
        />
        <h2 className="text-3xl md:text-4xl font-bold text-yellow-400 mb-6">ABOUT US</h2>
        <p className="text-xl md:text-2xl font-semibold text-gray-200 mb-6">
          6+ years of collective hands-on experience:
        </p>
        <ul className="text-lg text-gray-300 mb-10 space-y-4 max-w-md mx-auto">
          {experiencePoints.map((point, index) => (
            <li key={index} className="flex items-start text-left p-3 bg-gray-700/60 rounded-lg shadow-md hover:bg-gray-700/90 transition-colors">
              <Icon
                iconUrl={ICON_URLS.check}
                altText="Checkmark"
                size={20}
                wrapperClassName="bg-gray-800"
                className="mr-3 mt-0.5 flex-shrink-0"
              />
              <span className="text-base md:text-lg">{point}</span>
            </li>
          ))}
        </ul>
        <div className="text-lg text-gray-200 text-center max-w-2xl mx-auto bg-gray-700 p-6 rounded-lg shadow-md border border-gray-400/60">
          <p>
            When you partner with UK CREATION, our team dedicates time from day one to deeply understand your brand. This means in the future, you wont need to repeat yourself. We will already know your vibe, your vision, and how you want things done – making everything faster, smoother, and stress-free for you.
          </p>
        </div>
      </div>
    </section>
  );
};

const WhoNeedsThis: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [advantages, setAdvantages] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const generateAdvantages = useCallback(async (categoryName: string) => {
    setIsLoading(true);
    setError(null);
    setAdvantages([]);

    const prompt = `You are an expert marketing copywriter.
For a business category '${categoryName}', generate exactly 5 unique and compelling bullet points.
Each bullet point must be an impressive 'cold message' highlighting a key advantage of having a professional webpage for that specific category.
Focus on tangible benefits like increased trust, wider reach, enhanced credibility, direct customer engagement, and a strong competitive edge, tailored to '${categoryName}'.
Ensure each bullet point is concise (ideally under 15-20 words) and starts with an impactful statement or action verb.
Format the output as 5 distinct bullet points, each on a new line. Do not use any numbering or markdown list prefixes (like '-', '*', or numbers). Just provide the raw text for each point.`;

    const result = await fetchGeminiInsights(prompt, 5);

    if (result.data) {
      setAdvantages(result.data);
    } else {
      setError(result.error || `Could not generate specific advantages for ${categoryName}.`);
      setAdvantages([]);
    }
    setIsLoading(false);
  }, []);

  const handlePanelClick = (categoryName: string) => {
    if (selectedCategory === categoryName) {
      setSelectedCategory(null);
      setAdvantages([]);
      setError(null);
    } else {
      setSelectedCategory(categoryName);
      generateAdvantages(categoryName)
        .catch(err => {
            console.error(`Error invoking generateAdvantages for ${categoryName}:`, err);
            setError(`Failed to process request for ${categoryName}. Please try again.`);
            setIsLoading(false);
            setAdvantages([]);
        });
    }
  };

  return (
    <section className="py-12 bg-gray-900 rounded-lg shadow-xl border border-gray-400/60">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-yellow-400 mb-6">WHO IS THIS FOR?</h2>
        <p className="text-xl md:text-2xl font-semibold text-yellow-400 mb-10">
          The smarter way to start your digital journey – crafted for those who dream big, hustle hard, and want to be seen right.
        </p>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {WHO_NEEDS_THIS_POINTS.map((category, index) => {
            const isOpen = selectedCategory === category;
            return (
              <div key={index} className="bg-gray-800 rounded-lg shadow-lg overflow-hidden border border-gray-400/60">
                <button
                  onClick={() => handlePanelClick(category)}
                  className="w-full flex items-center justify-between p-5 text-left font-semibold text-yellow-400 hover:bg-gray-700 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                  aria-expanded={isOpen}
                  aria-controls={`advantages-panel-${index}`}
                >
                  <span className="text-xl font-semibold">{category}</span>
                  <Icon
                    iconUrl={ICON_URLS.chevronDown}
                    altText={isOpen ? "Collapse" : "Expand"}
                    size={20}
                    wrapperClassName="bg-transparent"
                    className={`transform transition-transform duration-300 ${isOpen ? 'rotate-180' : 'rotate-0'}`}
                  />
                </button>
                <div
                  id={`advantages-panel-${index}`}
                  className="transition-all duration-500 ease-in-out overflow-hidden"
                  style={{ maxHeight: isOpen ? '500px' : '0px', opacity: isOpen ? 1 : 0 }}
                >
                  <div className="p-5 border-t border-gray-700">
                    {isLoading && isOpen && (
                      <div className="flex flex-col items-center justify-center space-y-3 py-4">
                        <div className="relative w-12 h-12">
                          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-yellow-400"></div>
                          <img src={SPINNER_LOGO_URL} alt="Loading..." className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 h-6 w-6 object-contain"/>
                        </div>
                        <p className="text-yellow-400">Fetching advantages...</p>
                      </div>
                    )}
                    {!isLoading && error && isOpen && (
                      <div className="text-red-400 bg-red-900/30 p-4 rounded-md my-2 border border-red-500/50">
                        <p className="font-semibold text-lg">Oops! Something went wrong.</p>
                        <p className="text-sm mt-1">{error}</p>
                      </div>
                    )}
                    {!isLoading && !error && isOpen && advantages.length > 0 && (
                      <div className="text-left w-full">
                        <h4 className="text-xl font-bold text-white mb-3 text-center">
                          {category}
                        </h4>
                        <p className="text-base text-gray-300 italic mb-4 text-center">
                          Discover Why a Professional Webpage is a <strong className="text-yellow-400">Must-Have</strong> for Your Success!
                        </p>
                        <ul className="list-none space-y-3">
                          {advantages.map((advantage, idx) => (
                            <li key={idx} className="flex items-start p-3 bg-gray-700/80 rounded-md shadow-sm hover:bg-gray-700 transition-colors">
                              <Icon
                                iconUrl={ICON_URLS.arrowRight}
                                altText="Advantage"
                                size={18}
                                wrapperClassName="bg-transparent"
                                className="mr-3 mt-1 flex-shrink-0"
                              />
                              <span className="text-gray-200 text-base">{advantage}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                    {!isLoading && !error && isOpen && advantages.length === 0 && (
                      <p className="text-gray-400 text-base py-4">
                        No specific advantages could be generated at this time. Please try again or API key might be missing.
                      </p>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        <p className="text-lg md:text-xl text-gray-200 mt-12 font-semibold">
          If you're just starting or want to upgrade your digital identity this is for YOU.
        </p>
      </div>
    </section>
  );
};

const WhyThisMatters: React.FC = () => {
  const [expandedReasonTitle, setExpandedReasonTitle] = useState<string | null>(null);
  const [reasonInsights, setReasonInsights] = useState<Record<string, GeminiInsightsState>>({});

  const generateReasonInsights = useCallback(async (item: WhyThisMattersItem) => {
    setReasonInsights(prev => ({
      ...prev,
      [item.title]: { insights: [], isLoading: true, error: null }
    }));

    const prompt = `You are an elite branding strategist for UK CREATION, a company that builds premium, lead-generating websites.
For the core business principle titled "${item.title}", described as: "${item.description}", generate 3-4 powerful insights.
Each insight should be a short, impactful statement (around 10-20 words) explaining why this principle is crucial for a business's success in the digital age AND subtly hinting how a UK CREATION webpage helps them master this.
Use a confident, aspirational, and slightly exclusive brand voice. Avoid generic marketing jargon.
Provide each insight on a new line, without any bullet point markers (like '-', '*') or numbering. Just raw text lines.`;

    const result = await fetchGeminiInsights(prompt, 4);

    if (result.data) {
      setReasonInsights(prev => ({
        ...prev,
        [item.title]: { insights: result.data!, isLoading: false, error: null }
      }));
    } else {
      setReasonInsights(prev => ({
        ...prev,
        [item.title]: { insights: [], isLoading: false, error: result.error || `No specific insights generated for ${item.title}.` }
      }));
    }
  }, []);

  const handlePanelToggle = (item: WhyThisMattersItem) => {
    if (expandedReasonTitle === item.title) {
      setExpandedReasonTitle(null);
    } else {
      setExpandedReasonTitle(item.title);
      if (!reasonInsights[item.title] || (!reasonInsights[item.title].isLoading && (reasonInsights[item.title].insights.length === 0 || reasonInsights[item.title].error))) {
        generateReasonInsights(item)
          .catch(err => {
            console.error(`Error invoking generateReasonInsights for ${item.title}:`, err);
            setReasonInsights(prev => ({
                ...prev,
                [item.title]: { insights: [], isLoading: false, error: `Failed to process request for ${item.title}. Please try again.` }
            }));
          });
      }
    }
  };

  return (
    <section className="py-12 border border-gray-400/60 rounded-lg shadow-xl bg-gray-900">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-yellow-400 mb-10 text-center">SOLID REASONS</h2>
        <div className="space-y-6 max-w-4xl mx-auto">
          {WHY_THIS_MATTERS_DATA.map((item, index) => {
            const isOpen = expandedReasonTitle === item.title;
            const currentItemInsights = reasonInsights[item.title];
            return (
              <div key={index} className="bg-gray-800 rounded-lg shadow-xl overflow-hidden border border-gray-400/60">
                <button
                  onClick={() => handlePanelToggle(item)}
                  className="w-full flex items-center justify-between p-5 md:p-6 text-left hover:bg-gray-700/70 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                  aria-expanded={isOpen}
                  aria-controls={`insights-panel-${index}`}
                >
                  <div className="flex items-start space-x-4">
                    <Icon iconUrl={item.iconUrl} altText={item.title} size={32} wrapperClassName="bg-gray-900" className="mt-1 flex-shrink-0" />
                    <div>
                      <h3 className="text-xl lg:text-2xl font-semibold text-yellow-400 mb-1">{item.title}</h3>
                      <p className="text-gray-300 text-md lg:text-lg">{item.description}</p>
                    </div>
                  </div>
                  <Icon
                    iconUrl={ICON_URLS.chevronDown}
                    altText={isOpen ? "Collapse" : "Expand"}
                    size={24}
                    wrapperClassName="bg-transparent"
                    className={`transform transition-transform duration-300 ${isOpen ? 'rotate-180' : 'rotate-0'} text-yellow-400 ml-4 flex-shrink-0`}
                  />
                </button>
                <div
                  id={`insights-panel-${index}`}
                  className="transition-all duration-500 ease-in-out overflow-hidden"
                  style={{ maxHeight: isOpen ? '500px' : '0px', opacity: isOpen ? 1 : 0 }}
                >
                  <div className="p-5 md:p-6 border-t border-gray-700">
                    {currentItemInsights?.isLoading && (
                       <div className="flex flex-col items-center justify-center space-y-3 py-4">
                        <div className="relative w-12 h-12">
                          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-yellow-400"></div>
                          <img src={SPINNER_LOGO_URL} alt="Loading..." className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 h-6 w-6 object-contain"/>
                        </div>
                        <p className="text-yellow-400 mt-2">Crafting exclusive insights...</p>
                      </div>
                    )}
                    {!currentItemInsights?.isLoading && currentItemInsights?.error && (
                      <div className="text-red-400 bg-red-900/30 p-4 rounded-md my-2 border border-red-500/50">
                        <p className="font-semibold text-lg">Insights Unavailable</p>
                        <p className="text-sm mt-1">{currentItemInsights.error}</p>
                      </div>
                    )}
                    {!currentItemInsights?.isLoading && !currentItemInsights?.error && currentItemInsights?.insights && currentItemInsights.insights.length > 0 && (
                      <div className="text-left w-full">
                        <h4 className="text-xl lg:text-2xl font-bold text-white mb-4 text-center">
                          {item.title}
                        </h4>
                        <ul className="list-none space-y-3">
                          {currentItemInsights.insights.map((insight, idx) => (
                            <li key={idx} className="flex items-start p-3 bg-gray-700/80 rounded-md shadow hover:bg-gray-700 transition-colors">
                              <Icon
                                iconUrl={ICON_URLS.arrowRight}
                                altText="Insight"
                                size={18}
                                wrapperClassName="bg-transparent"
                                className="mr-3 mt-1 flex-shrink-0"
                              />
                              <span className="text-gray-200 text-base">{insight}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                     {!currentItemInsights?.isLoading && !currentItemInsights?.error && currentItemInsights?.insights && currentItemInsights.insights.length === 0 && (
                      <p className="text-gray-400 text-base py-4">
                        No specific insights could be generated at this time. API key might be missing.
                      </p>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

const getIconForItem = (itemTitle: string): string => {
  const title = itemTitle.toLowerCase();
  if (title.includes("full website")) return ICON_URLS.hosting;
  if (title.includes("campaign page")) return ICON_URLS.campaignLogic;
  if (title.includes("booking form")) return ICON_URLS.form;
  if (title.includes("qr code")) return ICON_URLS.qrCode;
  if (title.includes("hosting")) return ICON_URLS.hosting;
  if (title.includes("creative flow")) return ICON_URLS.tools;
  if (title.includes("mobile friendly")) return ICON_URLS.mobileOptimized;
  if (title.includes("whatsapp logic")) return ICON_URLS.whatsapp;
  return ICON_URLS.check;
};

const PricingTable: React.FC<PricingTableProps> = ({ isVisible, onRevealPricesClick }) => {
  return (
    <section id="pricing" className="py-12 bg-gray-800 rounded-lg shadow-xl border border-gray-400/60">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-yellow-400 mb-4">Think you're not like the rest?</h2>
        {!isVisible && (
          <div
            className="p-8 bg-gray-700 rounded-lg shadow-inner cursor-pointer hover:bg-gray-600 transition-colors animate-pulse border border-gray-400/60"
            onClick={onRevealPricesClick}
            role="button"
            tabIndex={0}
            onKeyPress={(e) => e.key === 'Enter' && onRevealPricesClick()}
            aria-label="Reveal prices by filling form"
          >
            <p className="text-2xl font-semibold text-yellow-400 flex items-center justify-center">
              <Icon iconUrl={ICON_URLS.lock} altText="" size={28} wrapperClassName="bg-transparent ring-0 !p-0" className="mr-2 text-yellow-400" />
              Prove it. Click to reveal.
            </p>
            <p className="text-sm text-gray-300 mt-2">Fill a quick form to unlock exclusive pricing.</p>
          </div>
        )}
        {isVisible && (
          <div className="overflow-x-auto transition-opacity duration-1000 ease-in-out opacity-100 animate-fadeIn">
            <table className="min-w-full bg-gray-700 text-gray-200 rounded-lg shadow-md border border-gray-400/60">
              <thead className="bg-gray-900 text-yellow-400">
                <tr>
                  <th className="py-3 px-4 text-left text-sm font-semibold uppercase tracking-wider">Item</th>
                  <th className="py-3 px-4 text-left text-sm font-semibold uppercase tracking-wider hidden md:table-cell">What You Get</th>
                  <th className="py-3 px-4 text-right text-sm font-semibold uppercase tracking-wider">Value</th>
                  <th className="py-3 px-4 text-right text-sm font-semibold uppercase tracking-wider">Offered</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-600">
                {PRICING_DATA.map((item: PricingItem, index: number) => (
                  <tr key={index} className="hover:bg-gray-600 transition-colors">
                    <td className="py-4 px-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Icon iconUrl={getIconForItem(item.item)} altText={item.item} size={20} wrapperClassName="bg-gray-800" className="mr-3"/>
                        {item.item}
                      </div>
                    </td>
                    <td className="py-4 px-4 hidden md:table-cell">{item.description}</td>
                    <td className="py-4 px-4 text-right line-through text-gray-400">{item.value}</td>
                    <td className="py-4 px-4 text-right font-bold text-yellow-400 text-lg">{item.offered}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p className="mt-4 text-sm text-green-400 flex items-center justify-center">
             <Icon iconUrl={ICON_URLS.check} altText="" size={20} wrapperClassName="bg-transparent ring-0 !p-0" className="mr-1 text-green-400" />
              Prices unlocked successfully!
            </p>
          </div>
        )}
      </div>
    </section>
  );
};

const BookingFormModal: React.FC<BookingFormModalProps> = ({ onSubmitSuccess, onClose }) => {
  const [formDataState, setFormDataState] = useState<FormData>({
    firstName: "",
    lastName: "",
    phone: "",
    email: "",
    pincode: "",
    businessCategory: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const fieldDisplayNames: Record<keyof FormData, string> = {
    firstName: 'First Name',
    lastName: 'Last Name',
    phone: 'Phone Number',
    email: 'Email ID',
    pincode: 'Pincode',
    businessCategory: 'Business Type/Category'
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormDataState({ ...formDataState, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);
    setSuccessMessage(null);

    for (const key in formDataState) {
      if (key === 'email') continue;
      const typedKey = key as keyof Exclude<FormData, 'email'>;
      if (!formDataState[typedKey]) {
        const fieldName = fieldDisplayNames[typedKey] || typedKey.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
        setError(`Please fill in ${fieldName.toLowerCase()}.`);
        setIsSubmitting(false);
        return;
      }
    }
    
    if (!formDataState.businessCategory) {
        setError(`Please select your ${fieldDisplayNames.businessCategory.toLowerCase()}.`);
        setIsSubmitting(false);
        return;
    }

    if (!/^\d{10}$/.test(formDataState.phone)) {
      setError('Please enter a valid 10-digit phone number.');
      setIsSubmitting(false);
      return;
    }
    if (!/^\d{6}$/.test(formDataState.pincode)) {
      setError('Please enter a valid 6-digit pincode.');
      setIsSubmitting(false);
      return;
    }

    try {
      const dataToPost = new URLSearchParams();
      for (const key in formDataState) {
        if (Object.prototype.hasOwnProperty.call(formDataState, key)) {
          const typedKey = key as keyof FormData;
          const value = formDataState[typedKey];
          if (typedKey === 'businessCategory') {
            dataToPost.append('category', value);
          } else {
            dataToPost.append(key, value);
          }
        }
      }
      dataToPost.append('timestamp', new Date().toISOString());

      await fetch(GOOGLE_SHEET_URL, {
        method: 'POST',
        mode: 'no-cors',
        body: dataToPost,
      });

      const { firstName, lastName, businessCategory, phone, pincode, email } = formDataState;
      const fullName = `${firstName || ''} ${lastName || ''}`.trim() || "Valued Customer";
      const businessInfo = businessCategory || "their business";
      const contactPhone = phone || "N/A";
      const contactPincode = pincode || "N/A";
      const contactEmail = email || "Not provided";

      const message = `
Hello UK CREATION Team,

My name is ${fullName}.
I'm interested in your web presence solutions for my venture: ${businessInfo}.

My contact details are:
- Phone: ${contactPhone}
- Pincode: ${contactPincode}
- Email: ${contactEmail}

I've just submitted my information through your website form and would like to discuss how we can move forward.

Thank you,
${firstName || "Valued Customer"}
`.trim().replace(/^\s+/gm, "");

      const whatsappUrl = `https://wa.me/917894564870?text=${encodeURIComponent(message)}`;
      if (typeof window !== 'undefined') {
        window.open(whatsappUrl, '_blank');
      }

      setSuccessMessage("Form submitted successfully! Revealing prices...");
      setIsSubmitting(false);
      
      setTimeout(() => {
        onSubmitSuccess(formDataState);
      }, 1500);

    } catch (caughtError) {
      console.error('Form submission error:', caughtError);
      setError('Failed to submit form. Please try again or check your network connection.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-[100] animate-fadeIn">
      <div className="bg-gray-800 p-6 md:p-8 rounded-lg shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto border border-gray-400/60">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-yellow-400">Unlock Your Exclusive Offer</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white text-3xl leading-none" aria-label="Close modal">&times;</button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          {(Object.keys(formDataState) as Array<keyof FormData>).map((field) => (
            <div key={field}>
              <label htmlFor={field} className="block text-sm font-medium text-gray-300 mb-1">
                {fieldDisplayNames[field]}
              </label>
              {field === 'businessCategory' ? (
                <select
                  name={field}
                  id={field}
                  value={formDataState[field]}
                  onChange={handleChange}
                  required
                  className="w-full p-3 bg-gray-700 text-gray-200 border border-gray-600 rounded-md focus:ring-yellow-400 focus:border-yellow-400 ring-1 ring-gray-500/30 appearance-none"
                >
                  <option value="" disabled className="text-gray-500">Select your {fieldDisplayNames[field].toLowerCase()}</option>
                  {WHO_NEEDS_THIS_POINTS.map((category) => (
                    <option key={category} value={category} className="text-gray-200 bg-gray-700">
                      {category}
                    </option>
                  ))}
                  <option value="Others" className="text-gray-200 bg-gray-700">Others</option>
                </select>
              ) : (
                <input
                  type={field === 'email' ? 'email' : (field === 'phone' || field === 'pincode' ? 'tel' : 'text')}
                  name={field}
                  id={field}
                  value={formDataState[field]}
                  onChange={handleChange}
                  className="w-full p-3 bg-gray-700 text-gray-200 border border-gray-600 rounded-md focus:ring-yellow-400 focus:border-yellow-400 placeholder-gray-500 ring-1 ring-gray-500/30"
                  placeholder={`Enter your ${fieldDisplayNames[field].toLowerCase()}`}
                  required={field !== 'email'}
                  pattern={field === 'phone' ? '\\d{10}' : (field === 'pincode' ? '\\d{6}' : undefined)}
                  title={field === 'phone' ? 'Enter 10 digit phone number' : (field === 'pincode' ? 'Enter 6 digit pincode' : undefined)}
                />
              )}
            </div>
          ))}
          {error && <p className="text-red-400 text-sm p-2 bg-red-900/50 rounded border border-red-500/50">{error}</p>}
          {successMessage && <p className="text-green-400 text-sm p-2 bg-green-900/50 rounded border border-green-500/50">{successMessage}</p>}
          <button
            type="submit"
            disabled={isSubmitting || !!successMessage}
            className="w-full bg-yellow-400 hover:bg-yellow-500 text-gray-900 font-semibold py-3 px-4 rounded-md transition-transform duration-200 ease-in-out transform hover:scale-105 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed ring-1 ring-yellow-600/50"
          >
            {isSubmitting ? 'Submitting...' : (successMessage ? 'Submitted!' : 'Submit & Reveal Prices')}
          </button>
        </form>
      </div>
    </div>
  );
};
    
const StickyShareButton: React.FC = () => {
  const [showShareOptions, setShowShareOptions] = useState(false);

  const handleShareClick = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: document.title,
          text: 'Check out UK CREATION for premium web presence!',
          url: window.location.href,
        });
        setShowShareOptions(false);
      } catch (error) {
        if (!(error instanceof DOMException && error.name === 'AbortError')) {
           setShowShareOptions(!showShareOptions);
        }
      }
    } else {
      setShowShareOptions(!showShareOptions);
    }
  };
  
  const pageUrl = typeof window !== 'undefined' ? window.location.href : '';
  const shareText = "Check out UK CREATION for premium web presence!";

  const manualShareOptions = [
    {
      name: "Copy Link",
      action: () => {
        if (navigator.clipboard) {
          navigator.clipboard.writeText(pageUrl)
            .then(() => alert("Link copied to clipboard!"))
            .catch(err => console.error("Failed to copy: ", err));
        } else {
          alert("Clipboard API not available. Please copy manually.");
        }
      },
      icon: ICON_URLS.linkVariant
    },
    { name: "WhatsApp", url: `https://wa.me/?text=${encodeURIComponent(shareText + " " + pageUrl)}`, icon: ICON_URLS.whatsapp },
    { name: "Facebook", url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(pageUrl)}`, icon: ICON_URLS.facebook },
    { name: "Twitter", url: `https://twitter.com/intent/tweet?url=${encodeURIComponent(pageUrl)}&text=${encodeURIComponent(shareText)}`, icon: ICON_URLS.twitter },
  ];

  return (
    <React.Fragment>
      <button
        onClick={handleShareClick}
        className="fixed top-4 right-4 bg-black text-yellow-400 p-3 rounded-full shadow-lg hover:bg-gray-800 transition-all duration-200 ease-in-out transform hover:scale-110 active:scale-95 z-[60]"
        aria-label="Share this page"
        title="Share this page"
      >
        <img src={ICON_URLS.share} alt="Share" className="w-6 h-6" />
      </button>

      {showShareOptions && (
        <div className="fixed top-20 right-4 bg-gray-800 p-4 rounded-lg shadow-xl z-[70] border border-yellow-400 w-48 animate-fadeIn ring-1 ring-gray-400/60 ring-offset-1 ring-offset-gray-800">
          <p className="text-sm text-yellow-400 mb-2 font-semibold">Share via:</p>
          <div className="space-y-1">
            {manualShareOptions.map(option => (
              option.url ? (
                <a
                  key={option.name}
                  href={option.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-2 text-gray-200 hover:text-yellow-400 transition-colors p-1 hover:bg-gray-700 rounded -mx-1"
                  onClick={() => setShowShareOptions(false)}
                >
                  <Icon iconUrl={option.icon} altText={option.name} size={18} wrapperClassName="bg-gray-900"/>
                  <span>{option.name}</span>
                </a>
              ) : (
                <button
                  key={option.name}
                  onClick={() => { if (option.action) option.action(); setShowShareOptions(false); }}
                  className="flex items-center space-x-2 text-gray-200 hover:text-yellow-400 transition-colors w-full text-left p-1 hover:bg-gray-700 rounded -mx-1"
                >
                  <Icon iconUrl={option.icon} altText={option.name} size={18} wrapperClassName="bg-gray-900"/>
                  <span>{option.name}</span>
                </button>
              )
            ))}
          </div>
          <button
            onClick={() => setShowShareOptions(false)}
            className="mt-3 text-xs text-gray-400 hover:text-white w-full text-right"
          >
            Close
          </button>
        </div>
      )}
    </React.Fragment>
  );
};

const Footer: React.FC = () => {
  return (
    <footer className="bg-black text-gray-300 py-12 mt-16">
      <div className="container mx-auto px-6 text-center">
        <div className="flex items-center justify-center mb-8">
          <Icon iconUrl={ICON_URLS.web} altText="" size={32} wrapperClassName="bg-gray-800 !p-0" className="mr-3 text-yellow-400" />
          <h3 className="text-3xl lg:text-4xl font-bold text-yellow-400">CONNECT WITH US</h3>
        </div>
        <div className="flex justify-center space-x-5 sm:space-x-8 mb-10">
          {SOCIAL_LINKS.map((link) => (
            <a
              key={link.name}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={`Connect on ${link.name}`}
              title={`Connect on ${link.name}`}
              className="text-gray-300 hover:text-yellow-400 transition-all duration-300 transform hover:scale-125 focus:scale-125 focus:outline-none focus:ring-2 focus:ring-yellow-500/50 rounded-full"
            >
              <Icon iconUrl={link.iconUrl} altText={link.name} size={32} wrapperClassName="bg-gray-800 hover:bg-gray-700" />
            </a>
          ))}
        </div>
        <p className="text-xl lg:text-2xl text-yellow-300 max-w-xl mx-auto leading-relaxed">
          It's not just a website. It's your new digital partner, and it starts today.
        </p>
        <p className="mt-10 text-sm text-gray-500">
          &copy; {new Date().getFullYear()} UK CREATION. All Rights Reserved.
        </p>
      </div>
    </footer>
  );
};

const IconPanel: React.FC = () => {
  const [expandedItemName, setExpandedItemName] = useState<string | null>(null);
  const [itemInsights, setItemInsights] = useState<Record<string, GeminiInsightsState>>({});

  const generateFeatureInsights = useCallback(async (itemName: string) => {
    setItemInsights(prev => ({
      ...prev,
      [itemName]: { insights: [], isLoading: true, error: null }
    }));

    const prompt = `You are a persuasive digital marketing assistant for UK CREATION.
For the web feature named '${itemName}', generate exactly 5 concise 'cold' bullet points.
Each bullet point should highlight a crucial benefit this feature offers when part of a professional website designed by UK CREATION.
Focus on direct business advantages like increased efficiency, better customer engagement, enhanced professionalism, or improved lead conversion, tailored to '${itemName}'.
Frame them as if you're quickly convincing a busy business owner of its value.
Ensure each point is short (10-20 words).
Provide each point on a new line. Do not use any numbering or markdown list prefixes (like '-', '*', or numbers). Just provide the raw text for each point.`;

    const result = await fetchGeminiInsights(prompt, 5);
    if (result.data) {
      setItemInsights(prev => ({
        ...prev,
        [itemName]: { insights: result.data!, isLoading: false, error: null }
      }));
    } else {
      setItemInsights(prev => ({
        ...prev,
        [itemName]: { insights: [], isLoading: false, error: result.error || `No specific insights generated for ${itemName}.` }
      }));
    }
  }, []);

  const handlePanelToggle = (itemName: string) => {
    if (expandedItemName === itemName) {
      setExpandedItemName(null);
    } else {
      setExpandedItemName(itemName);
      if (!itemInsights[itemName] || (!itemInsights[itemName].isLoading && (itemInsights[itemName].insights.length === 0 || itemInsights[itemName].error))) {
        generateFeatureInsights(itemName)
          .catch(err => {
            console.error(`Error invoking generateFeatureInsights for ${itemName}:`, err);
            setItemInsights(prev => ({
                ...prev,
                [itemName]: { insights: [], isLoading: false, error: `Failed to process request for ${itemName}. Please try again.` }
            }));
          });
      }
    }
  };

  return (
    <section className="py-12 border border-gray-400/60 rounded-lg shadow-xl bg-gray-900">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-yellow-400 mb-10 text-center">KEY FEATURES & BENEFITS</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {ICON_PANEL_ITEMS.map((item: IconPanelItem, index: number) => {
            const isOpen = expandedItemName === item.name;
            const currentItemState = itemInsights[item.name];
            const isGoogleSheet = item.name === "Google Sheet";
            return (
              <div key={item.name} className="bg-gray-800 rounded-lg shadow-xl overflow-hidden border border-gray-400/60">
                <button
                  onClick={() => handlePanelToggle(item.name)}
                  className="w-full flex flex-col items-center justify-center p-5 text-center hover:bg-gray-700/70 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                  aria-expanded={isOpen}
                  aria-controls={`feature-insights-${index}`}
                >
                  {isGoogleSheet ? (
                    <div className="bg-black rounded-[12px] p-1 mb-3 ring-0 w-10 h-10 flex items-center justify-center">
                      <img src={item.iconUrl} alt={item.name} width="64" height="64" className="object-contain w-full h-full" />
                    </div>
                  ) : (
                    <Icon iconUrl={item.iconUrl} altText={item.name} size={32} wrapperClassName={"bg-black"} className="mb-3" />
                  )}
                  <p className="text-xl font-semibold text-gray-200 mb-1">{item.name}</p>
                  <Icon
                    iconUrl={ICON_URLS.chevronDown}
                    altText={isOpen ? "Collapse" : "Expand"}
                    size={20}
                    wrapperClassName="bg-transparent"
                    className={`transform transition-transform duration-300 ${isOpen ? 'rotate-180' : 'rotate-0'} text-yellow-400 mt-1`}
                  />
                </button>
                <div
                  id={`feature-insights-${index}`}
                  className="transition-all duration-500 ease-in-out overflow-hidden"
                  style={{ maxHeight: isOpen ? '500px' : '0px', opacity: isOpen ? 1 : 0 }}
                >
                  <div className="p-5 border-t border-gray-700">
                    {currentItemState?.isLoading && (
                       <div className="flex flex-col items-center justify-center space-y-3 py-4">
                        <div className="relative w-12 h-12">
                          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-yellow-400"></div>
                          <img src={SPINNER_LOGO_URL} alt="Loading..." className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 h-6 w-6 object-contain"/>
                        </div>
                        <p className="text-yellow-400 mt-2">Fetching benefits...</p>
                      </div>
                    )}
                    {!currentItemState?.isLoading && currentItemState?.error && (
                      <div className="text-red-400 bg-red-900/30 p-4 rounded-md my-2 text-center border border-red-500/50">
                        <p className="font-semibold text-lg">Benefits Unavailable</p>
                        <p className="text-sm mt-1">{currentItemState.error}</p>
                      </div>
                    )}
                    {!currentItemState?.isLoading && !currentItemState?.error && currentItemState?.insights && currentItemState.insights.length > 0 && (
                      <div className="text-left w-full">
                        <h4 className="text-lg font-semibold text-yellow-300 mb-3 text-center">
                          Unlock the Power of <span className="underline decoration-wavy decoration-yellow-500 font-bold">{item.name}</span>:
                        </h4>
                        <ul className="list-none space-y-3">
                          {currentItemState.insights.map((insight, idx) => (
                            <li key={idx} className="flex items-start p-3 bg-gray-700/80 rounded-md shadow hover:bg-gray-700 transition-colors">
                             <Icon
                                iconUrl={ICON_URLS.arrowRight}
                                altText="Benefit"
                                size={18}
                                wrapperClassName="bg-transparent"
                                className="mr-3 mt-1 flex-shrink-0"
                              />
                              <span className="text-gray-200 text-base">{insight}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                    {!currentItemState?.isLoading && !currentItemState?.error && currentItemState?.insights && currentItemState.insights.length === 0 && (
                       <p className="text-gray-400 text-base py-4 text-center">
                        No specific benefits could be generated at this time. API key might be missing.
                      </p>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

interface PrepaidOfferProps {
  offerExpiryTimestamp: number | null;
}
const PrepaidOffer: React.FC<PrepaidOfferProps> = ({ offerExpiryTimestamp }) => {
    const [showQrModal, setShowQrModal] = useState(false);
    const [timeLeft, setTimeLeft] = useState<TimeLeft | null>(null);
    const [isOfferActiveState, setIsOfferActiveState] = useState<boolean>(false);

    const calculateTimeLeftForPrepaid = useCallback((): TimeLeft | null => {
        if (!offerExpiryTimestamp) return null;
        const difference = offerExpiryTimestamp - Date.now();
        if (difference <= 0) return null;
        return {
          days: 0, 
          hours: Math.floor(difference / (1000 * 60 * 60)),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60),
        };
    }, [offerExpiryTimestamp]);

    useEffect(() => {
        if (!offerExpiryTimestamp) {
          setIsOfferActiveState(false);
          setTimeLeft(null);
          return; 
        }
        const initialTimeLeft = calculateTimeLeftForPrepaid();
        if (initialTimeLeft) {
          setTimeLeft(initialTimeLeft);
          setIsOfferActiveState(true);
        } else { 
          setIsOfferActiveState(false);
          setTimeLeft(null);
          return; 
        }
        const timer = setInterval(() => {
          const newTimeLeft = calculateTimeLeftForPrepaid();
          if (newTimeLeft) {
            setTimeLeft(newTimeLeft);
            setIsOfferActiveState(true);
          } else {
            setTimeLeft(null);
            setIsOfferActiveState(false);
            clearInterval(timer);
          }
        }, 1000);
        return () => clearInterval(timer);
    }, [offerExpiryTimestamp, calculateTimeLeftForPrepaid]);
    
    const countdownText = timeLeft 
        ? `${String(timeLeft.hours).padStart(2, '0')}:${String(timeLeft.minutes).padStart(2, '0')}:${String(timeLeft.seconds).padStart(2, '0')}`
        : '00:00:00';

    return (
        <div className="mt-8 p-6 md:p-8 bg-gradient-to-br from-yellow-500 via-yellow-400 to-yellow-500 text-gray-900 rounded-xl shadow-2xl border-2 border-yellow-300 transform hover:scale-[1.02] transition-transform duration-300">
        <div className="text-center">
            <Icon iconUrl={ICON_URLS.star} altText="Exclusive Offer Star" size={48} wrapperClassName="bg-gray-800 inline-block" className="mb-4" />
            <h3 className="text-3xl md:text-4xl font-bold mb-3">Exclusive Prepaid Offer!</h3>
            <p className="text-lg md:text-xl mb-2">
            Grab this one-time deal! Pay upfront for any plan within 
            {isOfferActiveState ? (
                <strong className="text-red-700 text-xl md:text-2xl mx-1">{countdownText}</strong>
            ) : (
                <strong className="text-gray-700 text-xl md:text-2xl mx-1">00:00:00</strong>
            )}
            of form submission and get:
            </p>
            <p className="text-2xl font-bold text-green-700 mb-6">
            FREE items worth {PREPAID_OFFER_FREEBIES_TOTAL_VALUE}!
            </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8 text-center">
            {PREPAID_OFFER_FREEBIES_ITEMS.map(item => (
            <div key={item.name} className="p-4 bg-yellow-100/30 rounded-lg shadow-md border border-yellow-600">
                <Icon iconUrl={item.iconUrl} altText={item.name} size={32} wrapperClassName="bg-gray-800 inline-block" className="mb-2" />
                <p className="font-semibold text-gray-800">{item.name}</p>
                <p className="text-sm text-gray-700">(Value: {item.value})</p>
            </div>
            ))}
        </div>

        <button
            onClick={() => setShowQrModal(true)}
            disabled={!isOfferActiveState}
            className={`w-full font-bold py-4 px-6 rounded-lg text-xl shadow-lg transition-all duration-300 ease-in-out transform focus:outline-none focus:ring-4 focus:ring-opacity-50 flex items-center justify-center space-x-2
            ${isOfferActiveState 
                ? 'bg-gray-800 hover:bg-gray-900 text-yellow-400 hover:shadow-xl hover:-translate-y-1 focus:ring-yellow-300' 
                : 'bg-gray-500 text-gray-300 cursor-not-allowed'}`}
        >
            {isOfferActiveState ? (
            <React.Fragment>
                <Icon iconUrl={ICON_URLS.rocketLaunch} altText="" size={24} wrapperClassName="bg-transparent ring-0 !p-0" className="text-yellow-400" />
                <span>Secure Your FREE items - Pay Now!</span>
                <Icon iconUrl={ICON_URLS.rocketLaunch} altText="" size={24} wrapperClassName="bg-transparent ring-0 !p-0" className="text-yellow-400" />
            </React.Fragment>
            ) : (
            <React.Fragment>
                <Icon iconUrl={ICON_URLS.timer} altText="" size={24} wrapperClassName="bg-transparent ring-0 !p-0" className="text-gray-300"/>
                <span>Offer Expired</span>
                <Icon iconUrl={ICON_URLS.timer} altText="" size={24} wrapperClassName="bg-transparent ring-0 !p-0" className="text-gray-300"/>
            </React.Fragment>
            )}
        </button>

        {showQrModal && isOfferActiveState && (
            <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center p-4 z-[110] animate-fadeIn">
            <div className="bg-gray-800 p-6 md:p-8 rounded-lg shadow-xl w-full max-w-md text-center border-2 border-yellow-400">
                <h4 className="text-2xl font-bold text-yellow-400 mb-4">Scan to Pay with Google Pay</h4>
                <img src={GOOGLE_PAY_QR_CODE_URL} alt="Google Pay QR Code" className="w-64 h-64 mx-auto mb-6 rounded-md border-4 border-yellow-400" />
                <p className="text-gray-300 mb-4 text-sm">Scan this QR code using your Google Pay app to complete the payment for your chosen plan and avail the offer.</p>
                <p className="text-yellow-300 text-xs mb-4">Offer valid for <strong className="text-red-600">{countdownText}</strong></p>
                <button
                onClick={() => setShowQrModal(false)}
                className="mt-4 bg-yellow-500 hover:bg-yellow-600 text-gray-900 font-semibold py-2 px-6 rounded-md transition-colors duration-200"
                >
                Close
                </button>
            </div>
            </div>
        )}
        </div>
    );
};
// --- END OF COMPONENTS ---

// --- App.tsx ---
const OFFER_EXPIRY_LOCAL_STORAGE_KEY = 'ukCreationPrepaidOffer_v6';
const OFFER_DURATION_HOURS = 24;

const App: React.FC = () => {
  const [isPricingVisible, setIsPricingVisible] = useState(false);
  const [showBookingFormModal, setShowBookingFormModal] = useState(false);
  const [offerExpiryTimestamp, setOfferExpiryTimestamp] = useState<number | null>(null);

  useEffect(() => {
    try {
      const storedExpiry = localStorage.getItem(OFFER_EXPIRY_LOCAL_STORAGE_KEY);
      if (storedExpiry) {
        const expiryTimestampNum = parseInt(storedExpiry, 10);
        if (!isNaN(expiryTimestampNum) && expiryTimestampNum > Date.now()) {
          setOfferExpiryTimestamp(expiryTimestampNum);
        } else {
          localStorage.removeItem(OFFER_EXPIRY_LOCAL_STORAGE_KEY);
        }
      }
    } catch (e) {
        console.warn("localStorage access failed in App (useEffect for offer expiry). Prepaid offer persistence may not work.", e);
    }
  }, []);

  const handleRevealPricesClick = useCallback(() => {
    if (!isPricingVisible) {
      setShowBookingFormModal(true);
    }
  }, [isPricingVisible]);

  const handleFormSubmitSuccess = useCallback((formData: FormData) => {
    setIsPricingVisible(true);
    setShowBookingFormModal(false);
    console.log("Form data received in App:", formData);

    const now = new Date();
    const expiryTime = now.getTime() + OFFER_DURATION_HOURS * 60 * 60 * 1000;
    try {
        localStorage.setItem(OFFER_EXPIRY_LOCAL_STORAGE_KEY, expiryTime.toString());
    } catch (e) {
        console.warn("localStorage access failed in App (handleFormSubmitSuccess). Prepaid offer persistence may not work.", e);
    }
    setOfferExpiryTimestamp(expiryTime);
  }, []);

  const handleCloseModal = useCallback(() => {
    setShowBookingFormModal(false);
  }, []);

  const isOfferActive = offerExpiryTimestamp !== null && offerExpiryTimestamp > Date.now();

  return (
    <div className="min-h-screen font-sans text-gray-100 app-background bg-cover bg-center bg-no-repeat bg-fixed">
      <Header
        logoUrl={BRAND_LOGO_URL}
        title="UK CREATION"
        tagline="The Website You've Been Searching For. Finally, It's Here."
      />
      <main className="container mx-auto px-4 py-10 space-y-16">
        <section className="text-center mt-4 mb-0">
          <p className="text-3xl md:text-4xl font-bold text-yellow-400 tracking-tight leading-snug max-w-3xl mx-auto">
            You don't just need a website, you need a digital setup that looks sharp, earns trust, and brings real leads.
          </p>
        </section>
        <HeroBanner images={HERO_IMAGES_TOP} slideDirection="right" />
        <ValuePromiseBar />
        <WhoNeedsThis />
        <WhyThisMatters />
        <LimitedTimeDeal isPricingVisible={isPricingVisible} />
        <HeroBanner images={HERO_IMAGES_MID} slideDirection="left" />
        <AboutUs logoUrl={BRAND_LOGO_URL} />
        <PricingTable isVisible={isPricingVisible} onRevealPricesClick={handleRevealPricesClick} />
         <section id="booking-form-section" className="py-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-yellow-400 mb-6">GET STARTED & UNLOCK OFFER</h2>
          {!isPricingVisible ? (
            <p className="text-gray-200 md:text-lg max-w-xl mx-auto">
              Click the "Prices Are Locked" button in the Package & Pricing Table section above, or the "Limited Time Offer" bonus section, fill out a quick form, and we will unlock your exclusive pricing and contact you!
            </p>
          ) : (
            <div className="animate-fadeIn">
              <p className="text-green-400 font-semibold text-lg mb-6">Thank you! Your pricing is now unlocked above. We will contact you shortly.</p>
              {isOfferActive ? (
                <PrepaidOffer offerExpiryTimestamp={offerExpiryTimestamp} />
              ) : (
                <div className="mt-8 p-6 md:p-8 bg-gray-700 text-gray-400 rounded-xl shadow-lg border border-gray-600">
                  <h3 className="text-2xl font-semibold mb-2">⏳ Offer Expired ⏳</h3>
                  <p>Our special 24-hour prepaid offer has expired. Keep an eye out for future deals!</p>
                </div>
              )}
            </div>
          )}
        </section>
        <IconPanel />
      </main>
      <Footer />

      {showBookingFormModal && (
        <BookingFormModal
          onSubmitSuccess={handleFormSubmitSuccess}
          onClose={handleCloseModal}
        />
      )}
      <StickyShareButton />
    </div>
  );
};

// --- ReactDOM rendering part ---
document.addEventListener('DOMContentLoaded', () => {
  const rootElement = document.getElementById('root');
  if (!rootElement) {
    console.error("CRITICAL: Root element with ID 'root' was not found in the DOM. React app cannot be mounted.");
    document.body.innerHTML = '<div style="color: red; text-align: center; padding: 20px; font-family: sans-serif;">Error: Application failed to load. Root DOM element missing.</div>';
  } else {
     try {
      const root = ReactDOM.createRoot(rootElement);
      root.render(
        <StrictMode>
          <App />
        </StrictMode>
      );
    } catch (error) {
      console.error("CRITICAL: Error during React app rendering:", error);
      rootElement.innerHTML = '<div style="color: red; text-align: center; padding: 20px; font-family: sans-serif;">An unexpected error occurred while loading the application. Please try again later.</div>';
    }
  }
});
